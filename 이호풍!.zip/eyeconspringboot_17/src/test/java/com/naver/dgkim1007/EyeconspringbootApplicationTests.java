package com.naver.dgkim1007;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EyeconspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
