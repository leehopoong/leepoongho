function confirm_email() {
	var yncheck = $('.confirmyn').val();
	if (yncheck == "n") {
		msg = "email 중복검사를 하세요!"
		$('.modal').modal('show');
	}
}

function indexReload() {
	window.location.reload();
}

tinymce.init({
	selector: 'textarea',
	plugins: 'a11ychecker advcode casechange formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinycomments tinymcespellchecker',
	toolbar: 'addcomment showcomments casechange checklist code formatpainter table',
	toolbar_mode: 'floating',
	tinycomments_mode: 'embedded',
	tinycomments_author: 'Author name',
	width: '100%',
	branding: false
});
window.onload = function() {
	$('.ui.dropdown').dropdown();
};
function zipcodeFind(){

  new daum.Postcode({

            oncomplete: function(data) {

                // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

                // 각 주소의 노출 규칙에 따라 주소를 조합한다.

                // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.

                var fullAddr = ''; // 최종 주소 변수

                var extraAddr = ''; // 조합형 주소 변수

                // 사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.

                if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우

                    fullAddr = data.roadAddress;

                } else { // 사용자가 지번 주소를 선택했을 경우(J)

                    fullAddr = data.jibunAddress;

                }

                // 사용자가 선택한 주소가 도로명 타입일때 조합한다.

                if(data.userSelectedType === 'R'){

                    //법정동명이 있을 경우 추가한다.

                    if(data.bname !== ''){

                        extraAddr += data.bname;

                    }

                    // 건물명이 있을 경우 추가한다.

                    if(data.buildingName !== ''){

                        extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);

                    }

                    // 조합형주소의 유무에 따라 양쪽에 괄호를 추가하여 최종 주소를 만든다.

                    fullAddr += (extraAddr !== '' ? ' ('+ extraAddr +')' : '');

                }

                // 우편번호와 주소 정보를 해당 필드에 넣는다.

                document.getElementById('zipcode').value = data.zonecode; //5자리 새우편번호 사용

                document.getElementById('addr1').value = fullAddr;

                // 커서를 상세주소 필드로 이동한다.

                document.getElementById('addr2').focus();

            }

        }).open();

 };



$(document).ready(function() {
	
	$(document).on('click', '#venderexample td #deletebtn', function() {
		new FroalaEditor('textarea#froala-editor');
		var row = $(this).closest('tr');
		var td = row.children();
		var code = td.eq(1).text();
		alert('모달')

		$('.ui.modal').modal('show');

		$('#deleteok').on('click', function() {
			$.ajax({
				type: 'POST',
				data: { code: code },
				datatype: 'json',
				url: 'venderDeleteAjax',
				contentType: 'application/x-www-form-urlencoded; charset=euc-kr',
				success: function(data) {
					if (data == "y") {
						row.remove();
						$('#resultmessage').text("삭제 되었습니다.");
					} else {
						$('#resultmessage').text("삭제 되지 않았습니다.");
					}

					$('#successmessage').css('display', "block")
						.delay(1200).queue(function() {
							$('#successmessage').css('display', "none").dequeue();
						});
					$('.ui.modal').modal('hide');
				},
				error: function(xhr, status, error) {
					alert('ajax error' + xhr.status);
				}
			});
		});

		$('#deletecancel').on('click', function() {
			$('.ui.mini.modal.delete').modal('hide');
		});

	});
	
	$('#productexample').DataTable({
	
		deferRender: true,
		autoWidth: false,
		scrollY: 500,
		scrollCollapse: true,
		scroller: true,
		language: { search: "" }
	});
	$('#venderexample').DataTable({
	
		deferRender: true,
		autoWidth: false,
		scrollY: 500,
		scrollCollapse: true,
		scroller: true,
		language: { search: "" }
	});





	$('#tax3').on('click', function() {
		$('#salaryinsertform').attr('action', 'salsaytaxrun');
		$('#salaryinsertform').submit();
	});

	$('#tax2').on('click', function() {
		alert('삭제')
		$('#salaryinsertform').attr('action', 'salsaytaxdel');
		$('#salaryinsertform').submit();
	});

	$('.salarydeletebtn').on('click', function() {
		$('description').text("데이터 삭제 하것습니까?");
		$('')
		$('uimodal').modal('show');
		$('.ui.mini.modal.delete').modal('hide');

	})


	$('.ui.dropdown').dropdown();

	$('.ui.dropdown').dropdown({
		onChange: function(lang) {
			$.ajax({
				type: 'POST',
				data: { lang: lang },
				datatype: 'json',
				url: 'languageAjax',
				async: false,
				success: function(data) {
					console.log(data);
					setTimeout(function() {
						window.location.reload();
					}, 100);
				},
				error: function(xhr, status, error) {
				}
			});
		},
		forceSelection: false,
		selectOnKeydown: false,
		showOnFocus: false,
		on: "hover"
	});

	$('.confirm').on('click', function() {
		var email = $('#email').val();
		if (email == "") {
			$('.description').text("E-mail을 입력하세요!");
			$('.modal').modal('show');
			return;
		} else {
			var email = email;
			$.ajax({
				type: 'POST',
				data: { email: email },
				datatype: 'json',
				url: 'emailConfirmAjax',
				contentType: 'application/x-www-form-urlencoded; charset=euc-kr',
				success: function(data) {
					var msg = "";
					if (data == "y") {
						msg = "사용중인 email입니다!"
						$('.confirmyn').val('n');
						$('.description').text(msg);
						$('.modal').modal('show');
						$('#email').val('');
						$('#email').focus();
					} else {
						$('.confirmyn').val('y');
						msg = "사용 가능한 email입니다!"
						$('.description').text(msg);
						$('.modal').modal('show');
					}

				},
				error: function(xhr, status, error) {
					alert('ajax error' + xhr.status);
				}
			});
		}
		$('.ui.black.deny.button').modal('hide');
	});
	$('.empnof').on('click', function() {
		var empno = $('#empno').val();
		if (empno == "") {
			$('.description').text("사원번호를 입력하세요");
			$('.modal').modal('show');
			return;
		} else {
			var empno = empno;
			$.ajax({
				type: 'POST',
				data: { empno: empno },
				datatype: 'json',
				url: 'empnoConfirmAjax',
				contentType: 'application/x-www-form-urlencoded; charset=euc-kr',
				success: function(data) {
					var msg = "";
					if (data == "y") {
						msg = "사용중인 사원번호 입니다!"
						$('.confirmyn').val('n');
						$('.description').text(msg);
						$('.modal').modal('show');
						$('#empno').val('');
						$('#empno').focus();
					} else {
						$('.confirmyn').val('y');
						msg = "사용 가능한 사원번호 입니다!"
						$('.description').text(msg);
						$('.modal').modal('show');
					}

				},
				error: function(xhr, status, error) {
					alert('ajax error' + xhr.status);
				}
			});
		}
		$('.ui.black.deny.button').modal('hide');
	});
	$('.venderconfirm').on('click', function() {
		var code = $('#code').val();
		if (code == "") {
			$('.description').text("거래처코드를 입력하세요");
			$('.modal').modal('show');
			return;
		} else {
			var code = code;
			$.ajax({
				type: 'POST',
				data: { code: code },
				datatype: 'json',
				url: 'vencodeConfirmAjax',
				contentType: 'application/x-www-form-urlencoded; charset=euc-kr',
				success: function(data) {
					var msg = "";
					if (data == "y") {
						msg = "사용중인 코드 입니다!"
						$('.confirmyn').val('n');
						$('.description').text(msg);
						$('.modal').modal('show');
						$('#code').val('');
						$('#code').focus();
					} else {
						$('.confirmyn').val('y');
						msg = "사용 가능한 사원번호 입니다!"
						$('.description').text(msg);
						$('.modal').modal('show');
					}

				},
				error: function(xhr, status, error) {
					alert('ajax error' + xhr.status);
				}
			});
		}
		$('.ui.black.deny.button').modal('hide');
	});






	$('#viewphoto').on('click', function() {
		$('input[type=file]').click();
		return false;
	});

	$('#imgfile').on('change', function(event) {
		var imgpath = URL.createObjectURL(event.target.files[0]);
		$('#viewphoto').attr('src', imgpath);
	});

	$('#memberexample').DataTable({
		deferRender: true,
		autoWidth: false,
		scrollY: 500,
		scrollCollapse: true,
		scroller: true,
		language: { search: "" }
	});
	
	$('#salaryrollexample').DataTable({
//		aaSorting[]: 
		deferRender: true,
		autoWidth: false,
		scrollY: 500,
		scrollCollapse: true,
		scroller: true,
		language: { search: "" }
	});




	$(document).on('click', '#memberexample td #editbtn', function() {
		var row = $(this).closest('tr');
		var td = row.children();
		var email = td.eq(1).text();
		var level = td.eq(4).children().val();
		$('.ui.mini.modal').modal('show');

		$.ajax({
			type: 'POST',
			data: { email: email, level: level },
			datatype: 'json',
			url: 'memberUpdateAjax',
			contentType: 'application/x-www-form-urlencoded; charset=euc-kr',
			success: function(data) {
				if (data == "y") {
					$('#resultmessage').text("수정 되었습니다.");
				} else {
					$('#resultmessage').text("수정 되지 않았습니다.");
				}

				$('#successmessage').css('display', "block")
					.delay(1200).queue(function() {
						$('#successmessage').css('display', "none").dequeue();
					});
			},
			error: function(xhr, status, error) {
				alert('ajax error' + xhr.status);
			}
		});
	});

	$('.attachbtn').on('click', function() {
		$('#b_attach').click();
		$('#b_attach').change(function() {
			var filename = $('#b_attach').val();
			$('.b_attachname').attr('value', filename);
		});
	});

	$(document).on('click', '#memberexample td #deletebtn', function() {
		new FroalaEditor('textarea#froala-editor');
		var row = $(this).closest('tr');
		var td = row.children();
		var email = td.eq(1).text();
		alert('모달')

		$('.ui.modal').modal('show');

		$('#deleteok').on('click', function() {
			$.ajax({
				type: 'POST',
				data: { email: email },
				datatype: 'json',
				url: 'memberDeleteAjax',
				contentType: 'application/x-www-form-urlencoded; charset=euc-kr',
				success: function(data) {
					if (data == "y") {
						row.remove();
						$('#resultmessage').text("삭제 되었습니다.");
					} else {
						$('#resultmessage').text("삭제 되지 않았습니다.");
					}

					$('#successmessage').css('display', "block")
						.delay(1200).queue(function() {
							$('#successmessage').css('display', "none").dequeue();
						});
					$('.ui.modal').modal('hide');
				},
				error: function(xhr, status, error) {
					alert('ajax error' + xhr.status);
				}
			});
		});

		$('#deletecancel').on('click', function() {
			$('.ui.mini.modal.delete').modal('hide');
		});

	});

	$('.boarddelete').on('click', function() {
		$('.ui.mini.modal.boardmodal').modal('show');

		$('.modalcancel').on('click', function() {
			$('.ui.mini.modal.boardmodal').modal('hide');
			return;
		});
		$('.modaldelete').on('click', function() {
			$('.ui.mini.modal.boardmodal').modal('hide');
			var b_seq = $('#hidden_seq').val();
			document.location.href = "boardDelete?b_seq=" + b_seq;
		});
	});
	$('#salaryexample').DataTable({
		deferRender: true,
		autoWidth: false,
		scrollY: 500,
		scrollCollapse: true,
		scroller: true,
		language: { search: "" }
	});
	



});