package com.naver.dgkim1007.dao;

import java.util.ArrayList;


import com.naver.dgkim1007.entities.Vender;

public interface VenderDao {
	public int insertRow(Vender vender)throws Exception;
	public ArrayList<Vender> selectAll()throws Exception;
	public int updateRow(Vender vender) throws Exception;
	public Vender selectOne(String code)throws Exception;
	public int deleteAjax(String code) throws Exception;
	
}
