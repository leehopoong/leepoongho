package com.naver.dgkim1007;

import java.util.Locale;

import org.apache.ibatis.session.SqlSession;
import org.python.icu.util.Calendar;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class BalanceController {
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	BalanceController balance;
	
	
	@RequestMapping(value = "/balancesearch", method = RequestMethod.GET)
	public String balancesearch( Model model) throws Exception {
		String yyyys[] = new String[5];
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		int start = year - 2;
		for (int i = 0; i < yyyys.length; i++) {
			yyyys[i] = start++ + "";
		}

		String mms[] = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" };
		model.addAttribute("yyyys", yyyys);
		model.addAttribute("mms", mms);
		String thisyyyy = year + "";

		String thismm = String.format("%02d", cal.get(Calendar.MONTH) + 1);
		model.addAttribute("thisyyyy", thisyyyy);
		model.addAttribute("thismm", thismm);
		return "balance/balance_search";
	}
	
	

}
