package com.naver.dgkim1007.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.naver.dgkim1007.entities.Member;
import com.naver.dgkim1007.entities.Product;
import com.naver.dgkim1007.entities.Salary;
import com.naver.dgkim1007.entities.SalaryRoll;
import com.naver.dgkim1007.entities.SalaryRollViewForBean;

public interface ProductDao {
	public int insertRow(Product product) throws Exception;
	public ArrayList<Product> selectAll() throws Exception;
	public int updateRow(Product product) throws Exception;
}