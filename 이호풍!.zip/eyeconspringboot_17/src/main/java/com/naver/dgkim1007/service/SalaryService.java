//package com.naver.dgkim1007.service;
//
//import java.util.ArrayList;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import com.naver.dgkim1007.dao.SalaryDao;
//import com.naver.dgkim1007.entities.Salary;
//import com.naver.dgkim1007.entities.SalaryRoll;
//
//public class SalaryService implements SalaryDao{
//	@Autowired
//	SalaryDao salarydao;
//
//	@Override
//	public int insertRow(Salary salary) throws Exception {
//		return salarydao.insertRow(salary);
//	}
//
//	@Override
//	public Salary selectOne(String empno) throws Exception {
//		// TODO Auto-generated method stub
//		return salarydao.selectOne(empno);
//	}
//
//	@Override
//	public ArrayList<Salary> selectAll() throws Exception {
//		// TODO Auto-generated method stub
//		return salarydao.selectAll();
//	}
//
//	@Override
//	public int updateAjax(Salary salary) throws Exception {
//		// TODO Auto-generated method stub
//		return salarydao.updateAjax(salary);
//	}
//
//	@Override
//	public int deleteAjax(String empno) throws Exception {
//		// TODO Auto-generated method stub
//		return salarydao.deleteAjax(empno);
//	}
//
//	@Override
//	public void addHit(String empno) throws Exception {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public ArrayList<Salary> selectTaxYes() throws Exception {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public int insertsalaryroll(SalaryRoll salaryroll) throws Exception {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//
//}
