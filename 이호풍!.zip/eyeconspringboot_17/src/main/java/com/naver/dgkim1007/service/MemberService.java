package com.naver.dgkim1007.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.naver.dgkim1007.dao.MemberDao;
import com.naver.dgkim1007.entities.Member;

@Service
public class MemberService implements MemberDao {

	@Autowired
	MemberDao memberdao;

	@Override
	public Member selectOne(String email) throws Exception {
		// TODO Auto-generated method stub
		return memberdao.selectOne(email);
	}

	@Override
	public int insertRow(Member member) throws Exception {
		// TODO Auto-generated method stub
		return memberdao.insertRow(member);
	}

	@Override
	public int updateRow(Member member) throws Exception {
		// TODO Auto-generated method stub
		return memberdao.updateRow(member);
	}

	@Override
	public ArrayList<Member> selectAll() throws Exception {
		// TODO Auto-generated method stub
		return memberdao.selectAll();
	}

	@Override
	public int updateAjax(Member member) throws Exception {
		// TODO Auto-generated method stub
		return memberdao.updateAjax(member);
	}

	@Override
	public int deleteAjax(String email) throws Exception {
		// TODO Auto-generated method stub
		return memberdao.deleteAjax(email);
	}

	 
}