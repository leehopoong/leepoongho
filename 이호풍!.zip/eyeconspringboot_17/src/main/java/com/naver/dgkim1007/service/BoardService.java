package com.naver.dgkim1007.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.naver.dgkim1007.dao.BoardDao;
import com.naver.dgkim1007.entities.Board;
import com.naver.dgkim1007.entities.BoardPaging;

@Service
public class BoardService implements BoardDao {

	@Autowired
	BoardDao boarddao;

	@Override
	public Board selectOne(int b_seq) throws Exception {
		// TODO Auto-generated method stub
		return boarddao.selectOne(b_seq);
	}

	@Override
	public int insertRow(Board member) throws Exception {
		// TODO Auto-generated method stub
		return boarddao.insertRow(member);
	}

	@Override
	public int updateRow(Board member) throws Exception {
		// TODO Auto-generated method stub
		return boarddao.updateRow(member);
	}

	@Override
	public ArrayList<Board> selectAll() throws Exception {
		// TODO Auto-generated method stub
		return boarddao.selectAll();
	}

	@Override
	public int updateAjax(Board member) throws Exception {
		// TODO Auto-generated method stub
		return boarddao.updateAjax(member);
	}

	@Override
	public int deleteRow(int b_seq) throws Exception {
		// TODO Auto-generated method stub
		return boarddao.deleteRow(b_seq);
	}

	@Override
	public ArrayList<Board> selectPageList(BoardPaging boardpaging) throws Exception {
		// TODO Auto-generated method stub
		return boarddao.selectPageList(boardpaging);
	}

	@Override
	public int selectCountFirst() throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int selectCount(BoardPaging boardpaging) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<Board> findListBoard(BoardPaging boardpaging) throws Exception {
		// TODO Auto-generated method stub
		return boarddao.findListBoard(boardpaging);
	}

	@Override
	public void addHit(int b_seq) throws Exception {
		// TODO Auto-generated method stub
	}

	@Override
	public int insertReplyRow(Board Board) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int selectMaxStep(int b_ref) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

}