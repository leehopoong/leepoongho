package com.naver.dgkim1007;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.naver.dgkim1007.dao.BoardDao;
import com.naver.dgkim1007.dao.MemberDao;
import com.naver.dgkim1007.dao.ProductDao;
import com.naver.dgkim1007.entities.Board;
import com.naver.dgkim1007.entities.Member;
import com.naver.dgkim1007.entities.Product;

@Controller
public class ProductController {
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	Member member;

	@RequestMapping(value = "/product_insert", method = RequestMethod.GET)
	public String product_insert(Locale locale, Model model) throws Exception {
		
		return "product/product_insert";

	}
	@RequestMapping(value = "/product_insertsave", method = RequestMethod.POST)
	public String product_insertsave(Model model, @ModelAttribute Product product) throws Exception {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		dao.insertRow(product);
		return "index";
		
	}
	@RequestMapping(value = "/productList", method = RequestMethod.GET)
	public String productList(Locale locale, Model model) throws Exception {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		ArrayList<Product> products = dao.selectAll();
		model.addAttribute("products", products);
		return "product/product_list";
	}
	@RequestMapping(value = "/productupdate", method = RequestMethod.GET)
	public String productupdate(Locale locale, Model model) throws Exception {
		
		return "product/product_update";

	}
	@RequestMapping(value = "/productupdateSave", method = RequestMethod.POST)
	public String productupdateSave(Model model, @ModelAttribute Product product) throws Exception {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		dao.updateRow(product);
		return "redirect:puductList";
	}



}
