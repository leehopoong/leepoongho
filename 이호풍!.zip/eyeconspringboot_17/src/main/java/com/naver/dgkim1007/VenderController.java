package com.naver.dgkim1007;

import java.util.ArrayList;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.naver.dgkim1007.dao.MemberDao;
import com.naver.dgkim1007.dao.VenderDao;
import com.naver.dgkim1007.entities.Member;
import com.naver.dgkim1007.entities.Vender;
@Controller
public class VenderController {
	@Autowired
	Vender vender;
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping(value = "/venderinsert", method = RequestMethod.GET)
	public String venderinsert(Locale locale, Model model) {
		return "vender/vender_insert";
	}
	@RequestMapping(value = "/venderinsertSave", method = RequestMethod.POST)
	public String venderinsertSave(Model model,@ModelAttribute Vender vender) throws Exception {
		VenderDao dao = sqlSession.getMapper(VenderDao.class);
		dao.insertRow(vender);
		
		return "index";
		
	}
	
	@RequestMapping(value = "/venderlist", method = RequestMethod.GET)
	public String venderlist(Model model,@ModelAttribute Vender vender) throws Exception {
		VenderDao dao = sqlSession.getMapper(VenderDao.class);
		ArrayList<Vender> venders = dao.selectAll();
		model.addAttribute("venders",venders);
		
		return "vender/vender_list";
		
	}
	@RequestMapping(value = "/vencodeConfirmAjax", method = RequestMethod.POST)
	@ResponseBody
	public String vencodeConfirmAjax(@RequestParam String code) throws Exception {
		VenderDao dao = sqlSession.getMapper(VenderDao.class);
		Vender data = dao.selectOne(code);
		String row = "y";
		if (data == null) {
			row = "n";
		}
		return row;
	}
	
	@RequestMapping(value = "/venderupdate", method = RequestMethod.GET)
	public String venderupdate(Model model,@RequestParam String code,HttpSession session)throws Exception  {
		VenderDao dao  = sqlSession.getMapper(VenderDao.class);
		vender = dao.selectOne(code);
		model.addAttribute("vender",vender);
		return "vender/vender_update";
	}
	
	@RequestMapping(value = "/venderupdateSave", method = RequestMethod.POST)
	public String venderupSave(Model model,@ModelAttribute Vender vender) throws Exception {
		VenderDao dao = sqlSession.getMapper(VenderDao.class);
		dao.updateRow(vender);
		return "redirect:venderlist";
		
	}
	@RequestMapping(value = "/venderDeleteAjax", method = RequestMethod.POST)
	@ResponseBody
	public String venderDeleteAjax(Model model,@ModelAttribute Vender vender) throws Exception {
		VenderDao dao = sqlSession.getMapper(VenderDao.class);
		
		return "index";
	}
	

}
