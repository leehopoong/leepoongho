package com.naver.wlsrn1311;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.SynchronousQueue;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.naver.wlsrn1311.entitles.Board;
import com.naver.wlsrn1311.entitles.Member;
import com.naver.wlsrn1311.service.MemberDao;

@Controller
public class MemberController {
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	@Autowired
	Member member;

	@RequestMapping(value = "/emailConfrimAjax", method = RequestMethod.POST)
	@ResponseBody
	public String emailConfirmAjax(@RequestParam String email) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		Member data = dao.memberOne(email);

		String row = "y";
		if (data == null) {
			row = "n";
		}

		// System.out.println("--> ajax 호출");
		// System.out.println("email:"+email);
		return row;
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginup(Locale locale, Model model) {
		// @ModelAttribute Member member 는 submit 을 만나야됨.
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		int count = dao.memberAll();
		/*
		 * board.setId("korea"); board.setName("김한국");
		 */
		return "login/login";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:index";
	}

	@RequestMapping(value = "/loginUp", method = RequestMethod.POST)
	public String loginup(Locale locale, Model model, @ModelAttribute Member member, HttpSession session) {
		// @ModelAttribute Member member 는 submit 을 만나야됨.
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		Member data = dao.memberOne(member.getEmail());
		if (data == null) {
			return "login/login_fail";
		} else {
			boolean passchk = BCrypt.checkpw(member.getPassword(), data.getPassword());
			System.out.println("check : " + passchk);
			if (passchk) {
				session.setAttribute("sessionemail", data.getEmail());
				session.setAttribute("sessionname", data.getName());
				session.setAttribute("sessionphoto", data.getPhoto());
				session.setAttribute("sessionlevel", data.getMemlevel());

				return "redirect:index";
			} else {
				return "login/login_fail";
			}

		}
		// 비밀번호 암호화 하는법.

	}

	@RequestMapping(value = "/cancelInsert", method = RequestMethod.GET)
	public String cancelInsert(Locale locale, Model model) {
		return "index";
	}

	@RequestMapping(value = "/memberUpdate", method = RequestMethod.GET)
	public String memberUpdate(Locale locale, Model model, HttpSession session) {
		String email = (String) session.getAttribute("sessionemail");
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		Member row = dao.memberOne(email);
		model.addAttribute("row", row);
		return "member/member_update";
	}

	@RequestMapping(value = "/memberUpdateSave", method = RequestMethod.POST)
	public String memberUpdateSave(Model model, @ModelAttribute Member member,
			@RequestParam CommonsMultipartFile imgfile) throws IOException {
		// System.out.println("-------->oldphoto:"+member.getOldphoto());
		String filename = imgfile.getOriginalFilename();
		String path = "D:/AI/AISprintProject/src/main/webapp/resources/uploadimages/";
		String realpath = "resources/uploadimages/"; // server path
		if (filename.equals("")) {
			member.setPhoto(member.getOldphoto());
		} else {
			String cutemail = member.getEmail().substring(0, member.getEmail().indexOf("@"));
			byte bytes[] = imgfile.getBytes(); // 이미지를 2진타입으로
			try {
				BufferedOutputStream output = new BufferedOutputStream(
						new FileOutputStream(path + cutemail + filename));
				output.write(bytes);
				output.flush();
				output.close();
				member.setPhoto(realpath + cutemail + filename);
				MemberDao dao = sqlSession.getMapper(MemberDao.class);
				dao.memberUpdate(member);

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("----->cutemail:" + cutemail);
		}
		return "index";
	}

	@RequestMapping(value = "/memberUpdateAjax", method = RequestMethod.POST)
	@ResponseBody
	public String memberUpdateAjax(@RequestParam String email, int level) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		Member data = dao.memberOne(email);

		System.out.println("email:" + email);
		System.out.println("level:" + level);
		member.setEmail(email);
		member.setMemlevel(level);
		int result = dao.memberUpdateAjax(member);
		if (result > 0) {
			return "y";
		} else {
			return "n";
		}

	}

	@RequestMapping(value = "/memberInsert", method = RequestMethod.GET)
	public String memberInsert(Locale locale, Model model) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		return "memer/member_insert";
	}

	@RequestMapping(value = "/member_insertSave", method = RequestMethod.POST)
	public String member_insertSave(Model model, @ModelAttribute Member member) {
		// @ModelAttribute Member member 는 submit 을 만나야됨.
		if (member.getPhoto() == null) {
			member.setPhoto("resources/image/noimage.png");
		}
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		String encodepassword = passwordEncoder.encode(member.getPassword());
		System.out.println("encodepassword:" + encodepassword);
		member.setPassword(encodepassword);
		dao.memberInsert(member);
		// 비밀번호 암호화 하는법.
		return "index";
	}

	@RequestMapping(value = "/memberList", method = RequestMethod.GET)
	public String memberList(Locale locale, Model model) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		ArrayList<Member> members = dao.memberList();
		// Member data = null;
		// for(int i = 0; i<members.size(); ++i){
		// data = new Member();
		// data = members.get(i);
		// System.out.println(data.getEmail()+" "+data.getName());
		// } 일반for문으로 확인
		//
		// for(Member member:members){
		// System.out.println(member.getEmail());
		// } 향상된for문으로 sql안의 내용 확인

		model.addAttribute("members", members);

		return "member/member_list";
	}
	@RequestMapping(value = "/memberdeleteAjax", method = RequestMethod.POST)
	@ResponseBody
	public String memberdeleteAjax(@RequestParam String email) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		Member data = dao.memberOne(email);
		member.setEmail(email);
		int result = dao.memberdeleteAjax(member);
		if (result > 0) {
			return "y";
		} else {
			return "n";
		}

	}

}