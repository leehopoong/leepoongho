package com.naver.wlsrn1311;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.naver.wlsrn1311.service.MemberDao;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	 public String home(Locale locale, Model model) {
	  return "redirect:index";
	 }

	 @RequestMapping(value = "/index", method = RequestMethod.GET)
	 public String home1() {
	  return "index";
	 }
	 @RequestMapping(value = "/registerInsert", method = RequestMethod.GET)
		public String registerInsert(Locale locale, Model model) {
					return "member/member_insert";
		}
	 @RequestMapping(value = "/loginInsert", method = RequestMethod.GET)
		public String loginInsert(Locale locale, Model model) {
			
			return "login/login";
		}


	
}
