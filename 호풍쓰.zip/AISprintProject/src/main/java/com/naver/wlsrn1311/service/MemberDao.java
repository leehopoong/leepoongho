package com.naver.wlsrn1311.service;

import java.util.ArrayList;

import com.naver.wlsrn1311.entitles.Member;

public interface MemberDao {
	int memberAll();
	int memberUpdateAjax(Member member);
	void memberInsert(Member member);
	int memberUpdate(Member member);
	int memberdeleteAjax(Member email);
	Member memberOne(String email);
	ArrayList<Member> memberList();
	
}
