function confirm_email(){
	var yncheck = $('.confirmyn').val();
	if(yncheck=="n"){
		msg = "email 중복검사 하세요."
			$('.description').text(msg);
	        $('.modal').modal('show');
	}
	
}



$(document).ready(function() {
    $('.confirm').on('click', function(){
        var email = $('#email').val();
        if(email == ""){
        	$('.description').text("E-mail을 입력하라구");
            $('.modal').modal('show');
            return;
        } else {
        	var email = email;
        	$.ajax({
                type:'POST',
                data : "email="+email,
                datatype:'json',
                url : 'emailConfrimAjax',
                success : function(data){
                	var msg ="";
                	if(data =="y"){
                		msg="사용중인 email입니다!";
                		$('.confirmyn').val('n');
                		$('.description').text(msg);
                        $('.modal').modal('show');
                        $('#email').val('');
                        $('#email').focus();
                	}else{
                		$('.confirmyn').val('y');
                		msg = "사용 가능한 email입니다."
                		$('.description').text(msg);
                        $('.modal').modal('show');
                	}
                	
                },
                error : function(xhr, status, error){
                    alert('ajax error' + xhr.status);
                }
            });
            alert('E-mail: ' + email);
        }
        
        $('.ui.black.deny.button').modal('hide');
        
    });
    $('#viewphoto').on('click',function(){
    	$('input[type=file]').click();
    	return false;
    });
//    사진변경
    $('#imgfile').on('change',function(event){
    	var imgpath = URL.createObjectURL(event.target.files[0]);
    	$('#viewphoto').attr('src',imgpath);
    });
    
    $('#memberexample').DataTable( {
        deferRender:    true,
        scrollY:        400,
        scrollCollapse: true,
        scroller:       true
    } );
   
    $(document).on('click','#memberexample td #editbtn',function(){
//    	현재의 tr을 row 로 보겟다.
    	var row = $(this).closest('tr');
    	var td = row.children();
    	var email = td.eq(1).text();
    	var level = td.eq(4).children().val();
//    	input으로 만들어내서 value 로 해야함.
    	alert(email+""+level);
     	$.ajax({
            type:'POST',
            data : {email:email,level:level},
            datatype:'json',
            url : 'memberUpdateAjax',
            success : function(data){
            	if(data=="y"){
            		$('#resultmessage').text("수정되었습니다.");
            	}else{
            		$('#resultmessage').text("수정 되지 않았습니다.");
            	}
            	
                $('#successmessage').css('display', "block").delay(1200).queue(function(){
                   $('#successmessage').css('display', "none").dequeue();
                });
             },
            error : function(xhr, status, error){
                alert('ajax error' + xhr.status);
            }
        });
    });
    
    $(document).on('click','#memberexample td #deletebtn',function(){
    	var row = $(this).closest('tr');
    	var td = row.children();
    	var email = td.eq(1).text();
    	
    	 $('.ui.modal.delete').modal('show');
    	 $('#deleteok').on('click',function(){
	    	$.ajax({
	            type:'POST',
	            data : {email:email},
	            datatype:'json',
	            url : 'memberdeleteAjax',
	            success : function(data){
	            	if(data=="y"){
	            		row.remove();
	            		$('#resultmessage').text("삭제되었습니다.");
	            	}else{
	            		$('#resultmessage').text("삭제 되지 않았습니다.");
	            	}
	            	
	                $('#successmessage').css('display', "block").delay(1200).queue(function(){
	                   $('#successmessage').css('display', "none").dequeue();
	                   $('#.ui.modal.delete').modal('hide')
	                });
	             },
	            error : function(xhr, status, error){
	                alert('ajax error' + xhr.status);
	            }
	        });
    	 });
    	 $('#deletecancel').on('click',function(){
    		 $('#.ui.modal.delete').modal('hide');
    	 });
    });
    
});